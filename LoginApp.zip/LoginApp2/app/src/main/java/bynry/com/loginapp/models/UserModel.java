package bynry.com.loginapp.models;

import java.io.Serializable;

public class UserModel implements Serializable {

    
}
