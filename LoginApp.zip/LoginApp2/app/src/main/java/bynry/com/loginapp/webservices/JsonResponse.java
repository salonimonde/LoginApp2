package bynry.com.loginapp.webservices;

public class JsonResponse {
    public String SUCCESS = "success";
    public String message;
    public String result;
    public String status;
    public String nsc_id;

    public static String FAILURE = "failure";

}
