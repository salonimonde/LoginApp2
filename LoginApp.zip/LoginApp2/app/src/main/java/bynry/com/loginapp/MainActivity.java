package bynry.com.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText edtId, edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtId = findViewById(R.id.edt_email);
        edtPassword = findViewById(R.id.edt_password);
        Drawable drawable = edtId.getBackground(); // get current EditText drawable
        drawable.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP); // change the drawable color

        edtId.setBackground(drawable); // set the new drawable to EditText
        edtPassword.setBackground(drawable); // set the new drawable to EditText

    }
}
