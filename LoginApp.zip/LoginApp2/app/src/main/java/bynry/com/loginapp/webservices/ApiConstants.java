package bynry.com.loginapp.webservices;

public class ApiConstants {

    public static final String DOMAIN_URL_CIS = "http://192.168.1.42:8008";

    public static final String BASE_URL_CIS = DOMAIN_URL_CIS + "/api/";

    public static final String LOGIN_URL = BASE_URL_CIS + "user_login";

}
